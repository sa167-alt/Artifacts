---
name: Launch task
about: Track a task on the Aurora v2.0 launch project board
title: "[Launch] "
labels: []
assignees: ''
---

## Goal
<!-- One sentence on what success looks like. -->

## Acceptance criteria
- 
- 

## Owner availability
<!-- Note PTO or any reason the owner cannot drive this in the next 2 weeks. -->

## Last status update: YYYY-MM-DD
<!--
Update this line every time you make material progress.
The launch hygiene review treats issues whose date here is older than 14 days
as stale. Replace YYYY-MM-DD with today's date when you update.
-->
