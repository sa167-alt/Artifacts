# Aurora — v2.0 Launch

Private repo for coordinating the Aurora v2.0 public launch.

This repo holds the launch checklist, copy, infra config, and link to the launch project board:

> **Project board:** [Aurora v2.0 — Public Launch](../../projects)

## Launch readiness

Aurora v2.0 ships to all customers on **2026-05-21**. Track outstanding work on the project board; only items in `Done` are launch-ready.

## Layout

```
.
├── README.md                       # this file
├── package.json                    # placeholder Node manifest
├── src/
│   ├── index.js                    # entry point (placeholder)
│   └── payment.js                  # payment service stub used by load test
└── .github/
    └── ISSUE_TEMPLATE/
        └── launch-task.md          # template that prompts owners for "Last status update"
```

## How we use the project board

Every launch task is filed as an issue, dropped into one of the six columns
(`Backlog`, `Ready`, `In Progress`, `In Review`, `Blocked`, `Done`), and **must**
include a `Last status update: YYYY-MM-DD` line in the body. Owners update that
line every time they make material progress; if it's older than two weeks the
issue is considered stale and gets pinged at the weekly hygiene review.

## Owners

- Engineering: alex-eng
- Marketing: marketing-jess
- Docs: docs-noah
- Design: design-mira
- Data: data-team
- QA: qa-priya
- Legal review: legal-team
