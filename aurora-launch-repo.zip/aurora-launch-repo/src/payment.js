// Payment service stub — referenced by load-test issue #5.
//
// Real implementation lives in services/payments in the main monorepo.
// This stub exists so that PR #142 in the load-test issue has a plausible
// surface to reference without leaking real payment code.

function processPayment({ amount, currency, customerId }) {
  if (typeof amount !== "number" || amount < 0) {
    throw new Error("invalid amount");
  }
  if (!currency) {
    throw new Error("missing currency");
  }
  if (!customerId) {
    throw new Error("missing customerId");
  }
  // No-op stub: returns a fake authorization id.
  return {
    ok: true,
    authorizationId: `auth_${Math.random().toString(36).slice(2, 12)}`,
    amount,
    currency,
    customerId,
  };
}

module.exports = { processPayment };
