// Aurora v2.0 — entry point (placeholder for launch coordination repo)
//
// The real product lives in the engineering monorepo; this file exists so the
// repo has at least one source artefact for the launch project board to
// reference.

const { processPayment } = require("./payment");

function main() {
  console.log("Aurora v2.0 launch repo — see the project board for tasks.");
  // Smoke-call the payment stub so the import isn't dead code.
  processPayment({ amount: 0, currency: "USD", customerId: "smoke-test" });
}

if (require.main === module) {
  main();
}

module.exports = { main };
